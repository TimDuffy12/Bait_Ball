rho = .1;
n = 10;
coords = (10*rand(10,2) - 5);

%K nearest
k = 6;
Idx = knearest(coords, k);
Idx = Idx(:, 2:k);
%n = size(Idx(1,:));

C = zeros(n*(k-1),2);
%translate to origin
for i=1:n
   A = coords(Idx(i,:),:); %neighbors
   B = A - coords(i,:);         %shifted to origin
   C(5*(i-1)+1:5*i,:) = B;
end

%fishInts

D = fishInts(C, rho);

%orderedPairs

for i=1:n;
   
    D((5*i)-4:5*i, :) = orderedPairs(D((5*i)-4:5*i, :));
    
end 

%combineInts
E = [];
for i=1:n;
   
    E = [E;combineInts(D((5*i)-4:5*i, :))];
    
end 


%intFix


%newDirection


%New Coords