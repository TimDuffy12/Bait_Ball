function coord_Matrix = orderedPairs(new_ints)
    %sorts ordered pairs from lowest to highest left endpoint
    coord_Matrix = sortrows(new_ints);
    
end