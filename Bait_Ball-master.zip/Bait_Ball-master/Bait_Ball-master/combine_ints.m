function [comb_ints]=combine_ints(swap_pairs)

n = size(swap_pairs, 1);

for i=1:n-1
    if swap_pairs(i,1) > swap_pairs(i+1,1)
        if swap_pairs(i+1,2) > swap_pairs(i,2)
            comb_ints(i,2) = swap_pairs(i+1,2);
        end
    end
end


end