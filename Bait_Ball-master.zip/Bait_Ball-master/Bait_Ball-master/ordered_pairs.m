function coord_Matrix = ordered_pairs(new_ints)

    coord_Matrix = sortrows(new_ints);
    
end