function newints = swap_pairs(pairs)

newints = [min(pairs')' max(pairs')'];


end